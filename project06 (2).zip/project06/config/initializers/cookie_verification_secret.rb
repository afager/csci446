# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '80a2cebffb7f7e01ed47740dd84be22d3626ab8b62b10241c369814732452ee7d9481cced6621e625e53cdddd65e8f377772a6d2d08381ed98ef543967f573c3';
