    authorization do
      role :admin do
        has_permission_on :all
      end
      role :member do
        has_permission_on [:games], :to => [:edit,:create,:update,:new,:show, :index, :destoy]
		has_permission_on [:users], :to => [:edit, :destoy, :update]
      end
	  #Needed for guests to see pages correctly.
	  role :guest do
	    has_permission_on [:games], :to => [:index, :show]
	    has_permission_on [:users], :to => [:create]
	  end
    end

    